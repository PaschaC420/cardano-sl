﻿namespace Neo.SmartContract
{
    internal enum StackItemType : byte
    {
        ByteArray = 0x00,
        Boolean = 0x01,
        Integer = 0x02,
        InteropInterface = 0x40,
        Array = 0x80,
        Struct = 0x81,
        Map = 0x82,
    }
}
