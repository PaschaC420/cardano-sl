﻿namespace Neo.Network.P2P.Payloads
{
    public class TransactionResult
    {
        public UInt256 AssetId;
        public Fixed8 Amount;
    }
}
