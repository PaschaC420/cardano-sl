﻿namespace Neo.Network.P2P.Payloads
{
    public enum StateType : byte
    {
        Account = 0x40,
        Validator = 0x48
    }
}
