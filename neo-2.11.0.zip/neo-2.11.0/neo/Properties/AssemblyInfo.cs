using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("neo.UnitTests")]
