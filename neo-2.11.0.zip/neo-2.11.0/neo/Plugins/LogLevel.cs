﻿namespace Neo.Plugins
{
    public enum LogLevel : byte
    {
        Fatal,
        Error,
        Warning,
        Info,
        Debug
    }
}
