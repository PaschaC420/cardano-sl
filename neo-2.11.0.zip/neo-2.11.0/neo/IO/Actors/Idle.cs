﻿namespace Neo.IO.Actors
{
    internal sealed class Idle
    {
        public static Idle Instance { get; } = new Idle();
    }
}
