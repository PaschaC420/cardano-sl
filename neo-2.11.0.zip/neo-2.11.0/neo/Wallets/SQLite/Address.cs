﻿namespace Neo.Wallets.SQLite
{
    internal class Address
    {
        public byte[] ScriptHash { get; set; }
    }
}
